<?php
$db = new mysqli('localhost', 'root', '', 'db_name');
if(isset($_POST['form_submit']))
{  
  extract($_POST);
  if($email!="") :
    $email=mysqli_real_escape_string($db,$email);
    $emailval = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';    
    if(preg_match($emailval, $email)) :
    $db_check=$db->query("SELECT * FROM `email_user` WHERE email='$email'");
    $count=mysqli_num_rows($db_check);
    if($count< 1) :         
     $active_code=md5($email.time());
     $link = 'http://localhost/folder/unsubscribe.php?key='.$active_code; // Change your domain        
     $fetch=$db->query("INSERT INTO email_user(email,active_code) VALUES('$email','$active_code')");
     $to="$email"; //change to ur mail address
     $strSubject="Mostlikers | Email Subscription";
     $message = '<p>Thank you for subscribe with us.</p>' ;              
     $message .= '<p>Click here to unsubscribe your email : <a href="'.$link.'">unsubscribe</p>' ;              
     $headers = 'MIME-Version: 1.0'."\r\n";
     $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
     $headers .= "From: info@mostlikers.com";            
     $mail_sent=mail($to, $strSubject, $message, $headers);  
     $msg_sucess="Your request has been accepted!.";
      else :
        $msg="This $email email address is already subscribe with us.";
      endif;  
    else :
      $msg="Please enter your valid email id";
    endif;      
  else : 
    $msg="Please fill all mandatory fields";
  endif;
}
?> 
<html>
<head>
  <title>Simple Subscribe and Unsubscribe Script in PHP | Mostlikers</title>
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
   <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
   <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<style type="text/css">
.error{
margin-top: 6px;
margin-bottom: 0;
color: #fff;
background-color: #D65C4F;
display: table;
padding: 5px 8px;
font-size: 11px;
font-weight: 600;
line-height: 14px;
  }
  .green{
margin-top: 6px;
margin-bottom: 0;
color: #fff;
background-color: green;
display: table;
padding: 5px 8px;
font-size: 11px;
font-weight: 600;
line-height: 14px;
  }

</style>
</head>
<body>  
<div class="modal-dialog">
  <div class="row">
    <div class="col-md-12"> 
      <h3>Simple Subscribe and Unsubscribe Script in PHP</h3> 
        <a href="http://www.mostlikers.com/2015/11/simple-subscribe-and-unsubscribe-script.html">Tutorial Link</a>- mostlikers blog
        <a href="http://www.mostlikers.com">mostlikers.com</a>
    </div>
    <div class="col-md-12">         
      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      <!-- top menu -->
      <ins class="adsbygoogle"
      style="display:inline-block;width:728px;height:90px"
      data-ad-client="ca-pub-9665679251236729"
      data-ad-slot="6768833826"></ins>
      <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
      </script>
    </div>
  </div>
  <div class="row">
    <div class="modal-content col-md-8">
      <div class="modal-header">
        <h4 class="modal-title"><i class="icon-paragraph-justify2"></i> Subscribe my updates via Email</h4>
      </div>
      <form method="post" id="login_form">
        <div class="modal-body with-padding">                             
          <?php if(@$msg_sucess=="") : ?>
          <div class="form-group">
            <div class="row">
              <div class="col-sm-10">
                <label>Email *</label>
                <input type="text" name="email" class="form-control">
              </div>
            </div>
          </div>
          <?php endif; ?>
        </div>
        <div class="<?=(@$msg_sucess=="") ? 'error' : 'green' ; ?>" id="logerror"><?php echo @$msg; ?><?php echo @$msg_sucess; ?></div> 
        <div class="modal-footer">
          <?php if(@$msg_sucess=="") : ?>
          <input type="submit" id="btn-login" value="Submit" name="form_submit" class="btn btn-primary"> 
          <?php endif; ?>            
        </div>
      </form>          
    </div>
    <div class="col-md-2"></div>    
  </div>
</div>   
</body>
</html>







