<?php 
$db = new mysqli('localhost', 'root', '', 'mostlikers');
if(@$_GET['key']!=""):
    $active_code=mysqli_real_escape_string($db,$_GET['key']);
    $fetch=$db->query("SELECT * FROM `email_user` WHERE `active_code` = '$active_code'");
    $count=mysqli_num_rows($fetch);
    if($count==1) :
      $row=mysqli_fetch_array($fetch);      
        $db->query("DELETE `email_user` WHERE id='$user_id'");
        $msg="Your email id unsubscribe with us";
    else :
      $msg="Please click valid link.";
    endif;
else :
    header("Location:404.php");
endif;
?>

<!doctype html>
<html lang="en">
<head>
   <title>Simple Subscribe and Unsubscribe Script in PHP</title> 
</head>
<body>
    <div align="center">
    <h2><?php echo $msg; ?></h2>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      <!-- top menu -->
      <ins class="adsbygoogle"
      style="display:inline-block;width:728px;height:90px"
      data-ad-client="ca-pub-9665679251236729"
      data-ad-slot="6768833826"></ins>
      <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
      </script>
    <h4>Simple Subscribe and Unsubscribe Script in PHP </h4> 
        <a href="http://www.mostlikers.com/2015/11/simple-subscribe-and-unsubscribe-script.html">Tutorial Link</a>- mostlikers blog
        <a href="http://www.mostlikers.com">mostlikers.com</a>                          
                                
    </div>
